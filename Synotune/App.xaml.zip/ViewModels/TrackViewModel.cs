﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Synotune.ViewModels
{
    public class TrackViewModel
    {
        public string Title { get; set; }
    }
}
